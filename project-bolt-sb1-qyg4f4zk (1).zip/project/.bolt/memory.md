# Project memory

## Product intent & audience

- Single-page web app educating users about text-message scams (smishing/phishing) and fraud job detection.
- Primary audience: Indian consumers; includes India-specific reporting channels (cybercrime.gov.in, 1930 helpline, 1909 spam SMS, bank notification).
- Content must be in plain, easy-to-understand language for non-technical readers.
- Project name: Fraud Job Detection Platform.

## Brand personality & voice

- Helpful, calm, safety-focused.
- Avoid jargon; explain terms simply (e.g., smishing = scam arriving by SMS, also on WhatsApp/email).
- Action-oriented: step-by-step guidance where reporting is involved.
- Catchy, memorable taglines (e.g., "Check first, trust second.") reinforcing protect-yourself-and-family messaging.

## Visual design & UX direction

- Dark teal color palette; maintain consistently across sections.
- Expandable/collapsible FAQ items (accordion pattern) for Q&A.
- Scrolling safety-message ticker (marquee) below FAQ: continuously moving safety reminders (OTP, fake job offers, prize scams, 1930/1909 numbers); pauses on hover; seamless loop without gaps.
- Footer at very bottom: site name + shield icon, catchy safety line, then engineering team credits.
- Lucide React icons used throughout.
- Tailwind CSS for styling; React hooks for interactivity (FAQ toggle, ticker hover pause).

## Decisions, constraints & rationale

- Framework: vite-react; path alias `@/` → `src/`.
- No extra UI/icon/theme packages beyond lucide-react unless explicitly requested.
- Page order: primary guidance → FAQ → scrolling safety ticker → footer with team credits.
- Reporting guidance ordered by urgency (money lost → 1930 fast; general spam → 1909; always inform bank).
- Team members credited in footer: Siddharth Jha, Naman Agarwal, Vedant Kashikar, Tanmay Barik.

## Open questions & assumptions

- Assumed single-page layout; unknown if multi-page navigation is planned.
- No explicit brand/logo provided yet; design inferred from existing dark teal styling.
- India-only reporting context assumed unless broader localization requested.
- Language: English assumed for content; no mention of Hindi/regional language support yet.